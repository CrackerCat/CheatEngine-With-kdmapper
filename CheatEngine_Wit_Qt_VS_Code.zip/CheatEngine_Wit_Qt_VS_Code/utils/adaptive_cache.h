#pragma once
#include "TempPathManager.h"
#include <vector>
#include <string>
#include <mutex>
#include <fstream>
#include <filesystem>
#include <chrono>
#include <stdexcept>
#include <map>
#include <memory>
#include <atomic>
#include <thread>

#define THEAD_LOCAL_SIZE  50LL * 1024 *1024  //50MB


/// @brief ��������Ӧ�����������ӻ��浥Ԫ��
template <typename T>
class AdaptiveCache {
    static_assert(std::is_trivially_copyable_v<T>, "AdaptiveCache requires trivially copyable types.");

public:
    // ���޸ġ����캯������Ψһ��ʶ����ֹ���̴߳����ļ���ͻ
    explicit AdaptiveCache(size_t memThreshold = 100'000, std::string id = "default")
        : m_threshold(memThreshold), m_count(0), m_onDisk(false), m_uniqueId(id) {
        m_buffer.reserve(std::min(memThreshold, (size_t)10240));
    }

    ~AdaptiveCache() { clear(); }

    // ���ÿ�����֧���ƶ�
    AdaptiveCache(AdaptiveCache&& other) noexcept { moveFrom(std::move(other)); }
    AdaptiveCache& operator=(AdaptiveCache&& other) noexcept {
        if (this != &other) { clear(); moveFrom(std::move(other)); }
        return *this;
    }

    AdaptiveCache(const AdaptiveCache&) = delete;
    AdaptiveCache& operator=(const AdaptiveCache&) = delete;

    void push_back(const T& item) {
        std::lock_guard<std::mutex> lock(m_mtx);
        if (!m_onDisk) {
            m_buffer.push_back(item);
            if (m_buffer.size() >= m_threshold) flushToDisk();
        }
        else {
            ensureFileOpen();
            m_diskOut.write(reinterpret_cast<const char*>(&item), sizeof(T));
        }
        ++m_count;
    }

    void push_back_batch(const std::vector<T>& items) {
        if (items.empty()) return;
        std::lock_guard<std::mutex> lock(m_mtx);

        // ֻ�е�ǰ�Ѿ��ڴ��̣����� �ڴ�+������ ������ֵʱ����д����
        if (m_onDisk || (m_buffer.size() + items.size() >= m_threshold)) {
            if (!m_onDisk) flushToDisk(); // ��һ�γ�����ֵ�����ڴ����ȫ����ȥ

            ensureFileOpen();
            m_diskOut.write(reinterpret_cast<const char*>(items.data()), items.size() * sizeof(T));
            // ע�⣺��Ҫ��������� flush()���ò���ϵͳ�Լ����Ⱥϲ�д�룬�������
        }
        else {
            // ��û����ֵ��ֱ�ӽ��ڴ�
            m_buffer.insert(m_buffer.end(), items.begin(), items.end());
        }
        m_count += items.size();
    }



    size_t size() const {
        std::lock_guard<std::mutex> lock(m_mtx);
        return m_count;
    }

    // �ӵ�ǰ�ӻ����ȡ��Ƭ
    std::vector<T> readChunk(size_t start, size_t count) const {
        std::lock_guard<std::mutex> lock(m_mtx);
        std::vector<T> chunk;
        if (start >= m_count) return chunk;

        size_t end = std::min(start + count, m_count);
        size_t actualToRead = end - start;
        chunk.reserve(actualToRead);

        if (!m_onDisk) {
            chunk.assign(m_buffer.begin() + start, m_buffer.begin() + end);
        }
        else {
            // ע�⣺��ȡǰȷ��д�����ѹرջ� flush������ʹ�ö����� ifstream
            std::ifstream file(m_diskPath, std::ios::binary);
            if (file) {
                file.seekg(start * sizeof(T));
                T tmp;
                for (size_t i = 0; i < actualToRead && file.read(reinterpret_cast<char*>(&tmp), sizeof(T)); ++i) {
                    chunk.push_back(tmp);
                }
            }
        }
        return chunk;
    }

    void clear() {
        std::lock_guard<std::mutex> lock(m_mtx);
        m_buffer.clear();
        m_buffer.shrink_to_fit();
        if (m_diskOut.is_open()) m_diskOut.close();
        if (!m_diskPath.empty()) {
            std::error_code ec;
            std::filesystem::remove(m_diskPath, ec);
            m_diskPath.clear();
        }
        m_count = 0;
        m_onDisk = false;
    }

private:
    void moveFrom(AdaptiveCache&& other) {
        std::lock_guard<std::mutex> lock(other.m_mtx);
        m_buffer = std::move(other.m_buffer);
        m_diskPath = std::move(other.m_diskPath);
        m_diskOut = std::move(other.m_diskOut);
        m_count = other.m_count;
        m_threshold = other.m_threshold;
        m_onDisk = other.m_onDisk;
        m_uniqueId = std::move(other.m_uniqueId);
        other.m_count = 0;
        other.m_onDisk = false;
    }

    void ensureFileOpen() {
        if (!m_diskOut.is_open()) {
            if (m_diskPath.empty()) {
                auto dir = std::filesystem::path(TempPathManager::getWorkDir());
                auto ts = std::chrono::high_resolution_clock::now().time_since_epoch().count();
                // ���޸ġ��ļ�������Ψһ��ʶ�������ͻ
                m_diskPath = (dir / ("ACache_" + m_uniqueId + "_" + std::to_string(ts) + ".tmp")).string();
            }
            m_diskOut.open(m_diskPath, std::ios::binary | std::ios::app);
        }
    }

    void flushToDisk() {
        if (m_buffer.empty()) return;
        ensureFileOpen();
        m_diskOut.write(reinterpret_cast<const char*>(m_buffer.data()), m_buffer.size() * sizeof(T));
        m_diskOut.flush(); // ȷ��д�����
        m_buffer.clear();
        m_buffer.shrink_to_fit();
        m_onDisk = true;
    }

    mutable std::mutex m_mtx;
    std::vector<T> m_buffer;
    std::string m_diskPath;
    std::ofstream m_diskOut;
    size_t m_count;
    size_t m_threshold;
    bool m_onDisk;
    std::string m_uniqueId; // ��������ʵ��Ψһ ID
};

// =================================================================
// ��������AdaptiveCachePool���������ɨ���̵߳��ӻ���
// =================================================================
template <typename T>
class AdaptiveCachePool {
public:
    explicit AdaptiveCachePool(size_t perThreadThreshold = THEAD_LOCAL_SIZE)
        : m_perThreadThreshold(perThreadThreshold) {
    }

    /// @brief ��ȡ��ǰ�߳�ר�����ӻ��沢�������ݣ���ȫ����������
    void push_back(const T& item) {
        getThreadLocalCache().push_back(item);
    }

    void push_back_batch(const std::vector<T>& items) {
        if (items.empty()) return;
        // getThreadLocalCache ���Զ����ص�ǰ�̹߳����� AdaptiveCache ʵ��
        getThreadLocalCache().push_back_batch(items);
    }

    /// @brief ��ȡ��Ԫ������
    size_t total_size() const {
        std::lock_guard<std::mutex> lock(m_poolMtx);
        size_t total = 0;
        for (const auto& [id, cache] : m_subCaches) {
            total += cache->size();
        }
        return total;
    }

    /// @brief ͳһ��ҳ��ȡ���ۺ������ӻ��������
    std::vector<T> readChunk(size_t start, size_t count) const {
        std::lock_guard<std::mutex> lock(m_poolMtx);
        std::vector<T> result;
        size_t currentOffset = 0;
        size_t remainingToRead = count;

        for (const auto& [id, cache] : m_subCaches) {
            size_t cacheSize = cache->size();
            // ��鵱ǰ chunk �Ƿ���������ӻ���ķ�Χ��
            if (start < currentOffset + cacheSize) {
                size_t internalStart = (start > currentOffset) ? (start - currentOffset) : 0;
                size_t internalCount = std::min(remainingToRead, cacheSize - internalStart);

                auto subChunk = cache->readChunk(internalStart, internalCount);
                result.insert(result.end(), subChunk.begin(), subChunk.end());

                remainingToRead -= subChunk.size();
                start += subChunk.size(); // �ƶ����
                if (remainingToRead == 0) break;
            }
            currentOffset += cacheSize;
        }
        return result;
    }

    void clear() {
        std::lock_guard<std::mutex> lock(m_poolMtx);
        for (auto& [id, cache] : m_subCaches) {
            cache->clear();
        }
        m_subCaches.clear();
    }

private:
    /// @brief ���ķ�����Ϊÿ���̰߳��贴���򷵻����е��ӻ���
    AdaptiveCache<T>& getThreadLocalCache() {
        thread_local std::string tid = [] {
            std::stringstream ss;
            ss << std::this_thread::get_id();
            return ss.str();
            }();

        // ֻ���ڵ�һ�δ������̵߳��ӻ���ʱ�ż���
        std::lock_guard<std::mutex> lock(m_poolMtx);
        auto it = m_subCaches.find(tid);
        if (it == m_subCaches.end()) {
            auto newCache = std::make_unique<AdaptiveCache<T>>(m_perThreadThreshold, tid);
            auto& ref = *newCache;
            m_subCaches[tid] = std::move(newCache);
            return ref;
        }
        return *(it->second);
    }

    mutable std::mutex m_poolMtx;
    size_t m_perThreadThreshold;
    std::map<std::string, std::unique_ptr<AdaptiveCache<T>>> m_subCaches;
};