#include "process_enumerator_factory.h"
#include "win32_process_enumerator.h"   // Win32 ʵ��

std::unique_ptr<IProcessEnumerator> ProcessEnumeratorFactory::create(MemoryBackend type)
{
    switch (type)
    {
    case MemoryBackend::Win32:
        return std::make_unique<Win32ProcessEnumerator>();
        // δ����case MemoryBackend::DbkDriver: ...
    default:
        return nullptr;
    }
}