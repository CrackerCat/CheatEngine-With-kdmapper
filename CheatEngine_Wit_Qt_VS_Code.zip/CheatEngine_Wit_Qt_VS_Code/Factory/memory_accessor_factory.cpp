#include "memory_accessor_factory.h"
#include "win32_memory_accessor.h"

std::unique_ptr<IMemoryAccessor> MemoryAccessorFactory::create(MemoryBackend type)
{
    switch (type) {
    case MemoryBackend::Win32:
        return std::make_unique<Win32MemoryAccessor>();
        // δ������������ DBK ��������
        // case MemoryBackend::DbkDriver:
        //     return std::make_unique<DbkMemoryAccessor>();
    default:
        return nullptr;
    }
}