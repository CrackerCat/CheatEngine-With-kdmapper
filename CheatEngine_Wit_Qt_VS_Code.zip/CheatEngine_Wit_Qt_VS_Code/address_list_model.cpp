#include "address_list_model.h"
#include "process_manager.h"
#include <QBrush>
#include <QColor>

AddressListModel::AddressListModel(QObject* parent)
    : QAbstractTableModel(parent)
{
}

int AddressListModel::rowCount(const QModelIndex&) const
{
    return static_cast<int>(m_items.size());
}

int AddressListModel::columnCount(const QModelIndex&) const
{
    return 5; // Description, Address, Value, Type, Frozen
}

QVariant AddressListModel::data(const QModelIndex& index, int role) const
{
    if (!index.isValid())
        return {};
    if (index.row() < 0 || index.row() >= static_cast<int>(m_items.size()))
        return {};

    const auto& item = m_items[index.row()];

    // ��ʾ��ɫ
    if (role == Qt::DisplayRole) {
        switch (index.column()) {
        case 0: return item.description;
        case 1: { // ��ַ�У�ʹ��ģ�����
            std::string display;
            bool isBase = false;
            ProcessManager::instance().resolveAddress(item.address, display, isBase);
            return QString::fromStdString(display);
        }
        case 2: return item.value; // ��ֵ�У�ʮ���ƣ�
        case 3: { // ������
            switch (item.type) {
            case ValueType::Integer: return "Int";
            case ValueType::Float:   return "Float";
            case ValueType::Double:  return "Double";
            default: return "Unknown";
            }
        }
        case 4: return QVariant(); // �����в���ʾ�ı����ɸ�ѡ����
        }
    }
    // ǰ����ɫ����ַ��ַ��ɫ
    if (role == Qt::ForegroundRole && index.column() == 1) {
        std::string display;
        bool isBase = false;
        ProcessManager::instance().resolveAddress(item.address, display, isBase);
        if (isBase)
            return QBrush(QColor(0, 128, 0)); // ��ɫ
        return {};
    }
    // �����У���ѡ��״̬
    if (role == Qt::CheckStateRole && index.column() == 4) {
        return item.frozen ? Qt::Checked : Qt::Unchecked;
    }
    // ��ֵ�仯ʱ��죨��ѡ��
    if (role == Qt::ForegroundRole && index.column() == 2 && item.changed) {
        return QBrush(Qt::red);
    }
    return {};
}

QVariant AddressListModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (role != Qt::DisplayRole || orientation != Qt::Horizontal)
        return {};
    switch (section) {
    case 0: return "Description";
    case 1: return "Address";
    case 2: return "Value";
    case 3: return "Type";
    case 4: return "Frozen";
    }
    return {};
}

bool AddressListModel::setData(const QModelIndex& index, const QVariant& value, int role)
{
    if (!index.isValid() || index.row() >= static_cast<int>(m_items.size()))
        return false;

    if (role == Qt::CheckStateRole && index.column() == 4) {
        auto& item = m_items[index.row()];
        item.frozen = (value.toInt() == Qt::Checked);
        emit dataChanged(index, index, { Qt::CheckStateRole });
        return true;
    }
    // �����޸����� ?
    if (role == Qt::EditRole && index.column() == 0) {
        m_items[index.row()].description = value.toString();
        emit dataChanged(index, index, { Qt::DisplayRole });
        return true;
    }
    return false;
}

Qt::ItemFlags AddressListModel::flags(const QModelIndex& index) const
{
    Qt::ItemFlags flags = QAbstractTableModel::flags(index);
    if (index.column() == 4)
        flags |= Qt::ItemIsUserCheckable; // �����пɹ�ѡ
    if (index.column() == 0)
        flags |= Qt::ItemIsEditable;       // �����пɱ༭
    return flags;
}

void AddressListModel::addItem(uint64_t address, const QString& description, uint64_t value, ValueType type)
{
    beginInsertRows(QModelIndex(), m_items.size(), m_items.size());
    m_items.push_back({ description, address, value, type, false, 0, false });
    endInsertRows();
}

void AddressListModel::removeItem(int row)
{
    if (row < 0 || row >= static_cast<int>(m_items.size()))
        return;
    beginRemoveRows(QModelIndex(), row, row);
    m_items.erase(m_items.begin() + row);
    endRemoveRows();
}

void AddressListModel::clear()
{
    beginResetModel();
    m_items.clear();
    endResetModel();
}