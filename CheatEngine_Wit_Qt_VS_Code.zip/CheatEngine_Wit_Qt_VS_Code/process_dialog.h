#pragma once

#include <QDialog>
#include <QPushButton>
#include <QTableWidget>
#include "process_manager.h"
#include "process_info.h"

class ProcessDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ProcessDialog(QWidget* parent = nullptr);

    ProcessInfo selectedProcess() const;

private:
    QTabWidget* tabs;

    QTableWidget* appTable;   // �д���
    QTableWidget* allTable;   // ȫ������
    QPushButton* attachBtn;
    QPushButton* cancelBtn;


    std::vector<ProcessInfo> processes;
    void setupTable(QTableWidget* table);
    void populateTables();
};