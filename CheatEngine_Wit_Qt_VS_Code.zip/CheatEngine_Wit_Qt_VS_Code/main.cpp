#include "MainWindow.h"
#include <QtWidgets/QApplication>
#include "TempPathManager.h"


int main(int argc, char *argv[])
{
    TempPathManager::cleanupOrphanedDirs();
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
