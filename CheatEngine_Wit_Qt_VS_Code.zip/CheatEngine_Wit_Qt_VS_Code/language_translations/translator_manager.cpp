#include "translator_manager.h"
#include <QCoreApplication>
#include <QDir>
#include <QDebug>

TranslatorManager& TranslatorManager::instance()
{
    static TranslatorManager inst;
    return inst;
}

bool TranslatorManager::loadTranslation(const QString& language)
{
    removeTranslation();
    // �ӿ�ִ���ļ�ͬĿ¼�µ� Translate �ļ��м��� .qm
    QString qmPath = QCoreApplication::applicationDirPath() + "/language_Translate/Translation_" + language + ".qm";
    if (m_translator.load(qmPath)) {
        QCoreApplication::installTranslator(&m_translator);
        return true;
    }
    qWarning() << "Failed to load translation file:" << qmPath;
    return false;
}

void TranslatorManager::removeTranslation()
{
    QCoreApplication::removeTranslator(&m_translator);
}